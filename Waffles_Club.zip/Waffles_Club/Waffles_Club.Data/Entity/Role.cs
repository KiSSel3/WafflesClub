﻿namespace Waffles_Club.Data.Entity;

public class Role : BaseEntity
{
    public string Name { get; set; }
}