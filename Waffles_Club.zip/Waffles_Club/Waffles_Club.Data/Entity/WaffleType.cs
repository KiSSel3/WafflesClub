﻿namespace Waffles_Club.Data.Entity;

public class WaffleType : BaseEntity
{
    public string Name { get; set; }
    public string NormalizedName { get; set; }
}