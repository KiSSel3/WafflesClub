﻿namespace Waffles_Club.Extensions;

public class WebApplicationExtension
{
    
}