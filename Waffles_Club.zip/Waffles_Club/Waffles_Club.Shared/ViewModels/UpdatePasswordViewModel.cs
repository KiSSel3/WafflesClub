﻿namespace Waffles_Club.Shared.ViewModels;

public class UpdatePasswordViewModel
{
    public string CurrentPassword { get; set; }
    public string NewPassword { get; set; }
}